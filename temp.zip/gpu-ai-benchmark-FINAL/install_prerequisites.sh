#!/bin/bash

################################################################################
# GPU AI Benchmark Suite - Prerequisites Installer
# Installs all required dependencies for benchmarking
################################################################################

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
cat << "EOF"
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║          GPU AI Benchmark Suite - Installation               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
EOF
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
   echo -e "${RED}Please run as normal user (not root)${NC}"
   exit 1
fi

# Check NVIDIA GPU
echo -e "${YELLOW}Checking system requirements...${NC}"
if ! command -v nvidia-smi &> /dev/null; then
    echo -e "${RED}✗ nvidia-smi not found. Please install NVIDIA drivers first.${NC}"
    exit 1
fi

GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader | head -1)
GPU_VRAM=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader,nounits | head -1)
GPU_VRAM_GB=$((GPU_VRAM / 1024))

echo -e "${GREEN}✓ GPU detected: $GPU_NAME${NC}"
echo -e "${GREEN}✓ VRAM: ${GPU_VRAM_GB}GB${NC}"

# Check CUDA
if command -v nvcc &> /dev/null; then
    CUDA_VERSION=$(nvcc --version | grep "release" | awk '{print $6}' | cut -c2-)
    echo -e "${GREEN}✓ CUDA: $CUDA_VERSION${NC}"
else
    echo -e "${YELLOW}⚠ CUDA toolkit not found (optional)${NC}"
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python 3 not found. Installing...${NC}"
    sudo apt update
    sudo apt install -y python3 python3-pip
fi

PYTHON_VERSION=$(python3 --version | awk '{print $2}')
echo -e "${GREEN}✓ Python: $PYTHON_VERSION${NC}"

echo ""
echo -e "${YELLOW}Installing Python packages...${NC}"
echo ""

# Install PyTorch with CUDA support
echo "1/6 Installing PyTorch..."
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121 --break-system-packages

# Install Transformers
echo "2/6 Installing Transformers..."
pip3 install transformers datasets accelerate --break-system-packages

# Install utilities
echo "3/6 Installing utilities..."
pip3 install pandas psutil tqdm numpy pillow --break-system-packages

# Install llama.cpp
echo "4/6 Installing llama.cpp..."
cd ~
if [ -d "llama.cpp" ]; then
    echo "  llama.cpp already exists, updating..."
    cd llama.cpp
    git pull
else
    git clone https://github.com/ggerganov/llama.cpp
    cd llama.cpp
fi

echo "  Building llama.cpp with CUDA support..."
make clean
make LLAMA_CUDA=1 -j$(nproc)

# Create models directory
echo "5/6 Creating directories..."
mkdir -p ~/llama.cpp/models
mkdir -p ~/gpu-ai-benchmark/results
mkdir -p ~/gpu-ai-benchmark/downloads

# Test PyTorch CUDA
echo "6/6 Testing PyTorch CUDA..."
python3 << 'PYEOF'
import torch
import sys

if not torch.cuda.is_available():
    print("✗ PyTorch cannot access CUDA!")
    sys.exit(1)

device_count = torch.cuda.device_count()
device_name = torch.cuda.get_device_name(0)
print(f"✓ PyTorch CUDA: {device_count} GPU(s) detected")
print(f"✓ Device 0: {device_name}")
PYEOF

if [ $? -ne 0 ]; then
    echo -e "${RED}✗ PyTorch CUDA test failed${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}✓ Installation Complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "Next steps:"
echo -e "  1. Run benchmarks: ${BLUE}./run_all_benchmarks.sh${NC}"
echo -e "  2. Or run individual tests in ${BLUE}benchmarks/${NC}"
echo ""
echo -e "System Summary:"
echo -e "  GPU: $GPU_NAME"
echo -e "  VRAM: ${GPU_VRAM_GB}GB"
echo -e "  Python: $PYTHON_VERSION"
echo -e "  PyTorch: $(python3 -c 'import torch; print(torch.__version__)')"
echo ""
