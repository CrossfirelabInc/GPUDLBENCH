# GPU AI Benchmark Suite

A comprehensive, standalone benchmark suite for evaluating NVIDIA GPUs on AI/ML workloads. No Docker required, no complex configs - just run and compare.

## 🎯 Purpose

Compare GPU performance across:
- **Training**: ResNet-50, BERT-base, Mask R-CNN equivalent
- **Inference**: Same models in inference mode
- **LLM**: Token/second tests with 8 different model sizes
- **VRAM Limits**: What each GPU can/can't run
- **Mixed Precision**: FP32 vs FP16 speedup analysis

## 🚀 Quick Start

```bash
# 1. Clone or download this repository
git clone <your-repo-url>
cd gpu-ai-benchmark

# 2. Install prerequisites (CUDA, PyTorch, etc.)
chmod +x install_prerequisites.sh
./install_prerequisites.sh

# 3. Run all benchmarks (~2-3 hours)
chmod +x run_all_benchmarks.sh
./run_all_benchmarks.sh

# 4. View results
cat results/benchmark_summary.md
```

## 📊 What Gets Tested

### 1. Vision Training (ResNet-50, ResNet-101)
- FP32 and FP16 precision
- Multiple batch sizes (16, 32, 64, 128)
- Throughput in images/second
- **Comparable to**: Lambda Labs ResNet benchmarks

### 2. NLP Training (BERT-base, BERT-large)
- FP32 and FP16 precision
- Multiple batch sizes (8, 16, 32)
- Throughput in samples/second
- **Comparable to**: Lambda Labs BERT benchmarks

### 3. Object Detection Training (Faster R-CNN)
- FP32 and FP16 precision
- Detection throughput
- **Comparable to**: Lambda Labs Mask R-CNN benchmarks

### 4. Inference Performance
- All above models tested in inference mode
- Latency and throughput metrics
- **Comparable to**: Vast.ai inference tests

### 5. LLM Token Generation (GamersNexus methodology)
- **Models tested**:
  - DeepSeek Llama 8B Distil
  - Phi-4 (8-bit)
  - Qwen 2.5 14B
  - InternLM 20B
  - Mistral Small 22B
  - Gemma 2 27B
  - QwQ 32B
  - Llama 3.3 70B Q4
- Tokens/second measurement
- Time to first token (TTFT)
- **Comparable to**: GamersNexus GPU reviews

### 6. VRAM Limitation Tests
- Maximum model sizes per GPU
- Context length limits
- Multi-model deployment scenarios
- **Shows**: What 32GB can't do vs 48GB

### 7. Additional Tests
- Mixed precision speedup (FP16/FP32 ratio)
- Memory bandwidth utilization
- Power consumption tracking

## 📈 Output Format

Results are generated in multiple formats:

### 1. Comparison Table (Markdown)
```
| Benchmark              | A5000 (24GB) | RTX 5090 (32GB) | RTX 5000 BW (48GB) |
|------------------------|--------------|-----------------|---------------------|
| ResNet-50 FP32 (img/s) | 450          | 750             | 520                 |
| BERT-base FP32 (s/s)   | 120          | 200             | 140                 |
| Llama 70B Q4 (t/s)     | FAIL         | 13              | 28                  |
```

### 2. Raw Data (CSV)
- `training_vision.csv`
- `training_nlp.csv`
- `inference_vision.csv`
- `llm_performance.csv`
- `vram_limits.csv`

### 3. Summary Report (JSON)
```json
{
  "gpu": "NVIDIA RTX A5000",
  "vram": "24GB",
  "dlperf_estimate": 34.2,
  "training": {...},
  "inference": {...},
  "llm": {...}
}
```

## 🔧 System Requirements

- **OS**: Linux (Ubuntu 20.04+)
- **GPU**: NVIDIA with CUDA support
- **CUDA**: 11.8+ (12.0+ recommended)
- **RAM**: 32GB+ recommended
- **Storage**: 50GB free space (for models)
- **Python**: 3.8+

## 📦 What Gets Installed

The `install_prerequisites.sh` script installs:
- PyTorch with CUDA support
- Transformers (Hugging Face)
- torchvision, datasets
- llama.cpp with CUDA
- psutil, pandas, tqdm
- Model weights (downloaded on first run)

## 🎮 GPU Support

Tested on:
- RTX 4090, RTX 3090, RTX 3080
- RTX A6000, RTX A5000, RTX A4000
- RTX 5090 (Blackwell)
- RTX 5000 Blackwell (48GB)

Auto-adjusts batch sizes based on detected VRAM.

## 📝 Benchmark Methodology

### Training Benchmarks
- **Warmup**: 10 iterations (excluded from results)
- **Test**: 100 iterations for averaging
- **Metric**: Average throughput (items/second)
- **Synchronization**: CUDA sync before/after each iteration
- **Based on**: Lambda Labs methodology

### Inference Benchmarks
- **Warmup**: 10 iterations
- **Test**: 100 iterations
- **Metric**: Latency (ms) and throughput (items/second)
- **Mode**: `model.eval()` with `torch.no_grad()`

### LLM Benchmarks
- **Method**: llama.cpp with CUDA backend
- **Test**: 512 token generation per model
- **Metric**: Tokens/second, Time to First Token
- **Based on**: GamersNexus GPU review methodology

### VRAM Tests
- **Method**: Progressive model loading until OOM
- **Tests**: Max model size, max context length, multi-model
- **Shows**: Practical limits of 24GB vs 32GB vs 48GB

## 🔍 Understanding Results

### DLPerf Score
Approximate Vast.ai DLPerf score calculated as:
```
DLPerf ≈ (ResNet-50 Training Throughput) / 13.0
```

Reference scores:
- RTX 5090: 72-76
- RTX 4090: 60-65
- RTX 5000 Blackwell: 48-52
- RTX A5000: 32-36

### Performance Tiers
- **Excellent**: >90% of reference GPU performance
- **Good**: 80-90% of reference
- **Fair**: 70-80% of reference
- **Poor**: <70% (check for issues)

## 🐛 Troubleshooting

### Out of Memory Errors
Benchmark auto-adjusts batch sizes, but if you still get OOM:
```bash
# Edit config
nano benchmarks/config.py

# Reduce batch sizes
BATCH_SIZES_TRAIN = [8, 16, 32]  # Instead of [16, 32, 64]
```

### Slow Downloads
Models are downloaded from Hugging Face. If slow:
```bash
# Use a different mirror
export HF_ENDPOINT=https://hf-mirror.com
```

### GPU Not Detected
```bash
# Check CUDA
nvidia-smi

# Check PyTorch CUDA
python -c "import torch; print(torch.cuda.is_available())"
```

## 📊 Sample Results

### RTX A5000 (24GB, with desktop overhead)
```
Training Performance:
  ResNet-50 FP32:    243 img/s
  ResNet-50 FP16:    486 img/s
  BERT-base FP32:    98 samples/s
  BERT-base FP16:    196 samples/s

LLM Performance:
  DeepSeek 8B:       45 t/s
  Qwen 14B:          28 t/s
  Llama 70B Q4:      FAIL (OOM)

DLPerf Estimate:   18.7 (with overhead)
DLPerf Clean:      ~34 (estimated without overhead)
```

## 🤝 Contributing

This is an open-source benchmark suite. Contributions welcome!

Areas for contribution:
- Additional model support
- More GPU architectures
- Power consumption tracking
- Temperature monitoring
- Cloud platform integration

## 📄 License

MIT License - Free to use, modify, and distribute

## 🙏 Credits

Methodology based on:
- Lambda Labs deep learning benchmarks
- Vast.ai GPU comparison methodology
- GamersNexus GPU reviews
- MLPerf inference benchmarks

## 📬 Contact

For issues, suggestions, or results sharing:
- Open an issue on GitHub
- Share your results in Discussions

---

**Made for the AI/ML community to make informed GPU purchasing decisions** 🚀
