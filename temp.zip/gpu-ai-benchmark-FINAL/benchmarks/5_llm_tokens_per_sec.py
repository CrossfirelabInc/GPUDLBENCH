#!/usr/bin/env python3
"""
LLM Token Generation Benchmark
Based on GamersNexus methodology
Uses llama.cpp for testing
"""

import subprocess
import json
import csv
import os
import sys
from pathlib import Path
import time

# Models to test (GamersNexus list)
MODELS = [
    {
        'name': 'DeepSeek-R1-Distill-Llama-8B',
        'file': 'deepseek-llama-8b-q4.gguf',
        'url': 'https://huggingface.co/deepseek-ai/DeepSeek-R1-Distill-Llama-8B-GGUF/resolve/main/DeepSeek-R1-Distill-Llama-8B-Q4_K_M.gguf',
        'size_gb': 4.5,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'Phi-4',
        'file': 'phi-4-q8.gguf',
        'url': 'https://huggingface.co/bartowski/Phi-4-GGUF/resolve/main/Phi-4-Q8_0.gguf',
        'size_gb': 15,
        'quant': 'Q8_0'
    },
    {
        'name': 'Qwen2.5-14B',
        'file': 'qwen2.5-14b-q4.gguf',
        'url': 'https://huggingface.co/Qwen/Qwen2.5-14B-Instruct-GGUF/resolve/main/qwen2.5-14b-instruct-q4_k_m.gguf',
        'size_gb': 9,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'InternLM2-Chat-20B',
        'file': 'internlm2-20b-q4.gguf',
        'url': 'https://huggingface.co/TheBloke/internlm-chat-20b-GGUF/resolve/main/internlm-chat-20b.Q4_K_M.gguf',
        'size_gb': 13,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'Mistral-Small-22B',
        'file': 'mistral-small-22b-q4.gguf',
        'url': 'https://huggingface.co/bartowski/Mistral-Small-Instruct-2409-GGUF/resolve/main/Mistral-Small-Instruct-2409-Q4_K_M.gguf',
        'size_gb': 14,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'Gemma-2-27B',
        'file': 'gemma2-27b-q4.gguf',
        'url': 'https://huggingface.co/bartowski/gemma-2-27b-it-GGUF/resolve/main/gemma-2-27b-it-Q4_K_M.gguf',
        'size_gb': 17,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'QwQ-32B',
        'file': 'qwq-32b-q4.gguf',
        'url': 'https://huggingface.co/Qwen/QwQ-32B-Preview-GGUF/resolve/main/qwq-32b-preview-q4_k_m.gguf',
        'size_gb': 20,
        'quant': 'Q4_K_M'
    },
    {
        'name': 'Llama-3.3-70B',
        'file': 'llama-3.3-70b-q4.gguf',
        'url': 'https://huggingface.co/bartowski/Llama-3.3-70B-Instruct-GGUF/resolve/main/Llama-3.3-70B-Instruct-Q4_K_S.gguf',
        'size_gb': 42,
        'quant': 'Q4_K_S'
    },
]

PROMPT = "Explain the concept of machine learning, including supervised learning, unsupervised learning, and deep learning. Provide examples of each and discuss their real-world applications."

NUM_TOKENS = 512

def download_model(model, models_dir):
    """Download model if not already present"""
    model_path = models_dir / model['file']
    
    if model_path.exists():
        print(f"    ✓ Model already downloaded")
        return model_path
    
    print(f"    Downloading {model['name']} ({model['size_gb']:.1f}GB)...")
    print(f"    This may take a while...")
    
    try:
        subprocess.run([
            'wget', '-O', str(model_path), model['url'],
            '--progress=bar:force:noscroll', '-q'
        ], check=True)
        print(f"    ✓ Download complete")
        return model_path
    except subprocess.CalledProcessError:
        print(f"    ✗ Download failed")
        return None

def benchmark_model(model, model_path, llama_cli):
    """Benchmark a single model"""
    
    print(f"  Running benchmark on {model['name']}...", end=' ', flush=True)
    
    # Check if model file exists
    if not model_path or not model_path.exists():
        print("SKIP (download failed)")
        return {
            'model': model['name'],
            'size_gb': model['size_gb'],
            'quantization': model['quant'],
            'tokens_generated': None,
            'total_time_s': None,
            'tokens_per_second': None,
            'time_to_first_token_ms': None,
            'status': 'download_failed'
        }
    
    try:
        # Run llama.cpp
        result = subprocess.run([
            str(llama_cli),
            '-m', str(model_path),
            '-n', str(NUM_TOKENS),
            '-p', PROMPT,
            '-ngl', '999',  # Offload all layers to GPU
            '--temp', '0.7',
            '-b', '512',  # Batch size
        ], capture_output=True, text=True, timeout=300)
        
        output = result.stderr  # llama.cpp outputs to stderr
        
        # Parse output
        tokens_generated = None
        total_time = None
        tokens_per_sec = None
        
        for line in output.split('\n'):
            if 'llama_print_timings:' in line and 'eval time' in line:
                # Example: "llama_print_timings:        eval time = 1234.56 ms / 512 tokens (  24.13 ms per token,   41.44 tokens per second)"
                parts = line.split('/')
                if len(parts) >= 2:
                    time_part = parts[0].split('=')[-1].strip().split()[0]
                    total_time = float(time_part) / 1000  # Convert to seconds
                    
                    tokens_part = parts[1].strip().split()[0]
                    tokens_generated = int(tokens_part)
                    
                    # Extract tokens/sec
                    if 'tokens per second' in line:
                        tps_part = line.split('tokens per second')[0].split('(')[-1].strip()
                        tokens_per_sec = float(tps_part)
        
        if tokens_per_sec:
            print(f"{tokens_per_sec:.1f} t/s")
            return {
                'model': model['name'],
                'size_gb': model['size_gb'],
                'quantization': model['quant'],
                'tokens_generated': tokens_generated,
                'total_time_s': total_time,
                'tokens_per_second': tokens_per_sec,
                'time_to_first_token_ms': None,  # Would need separate measurement
                'status': 'success'
            }
        else:
            print("ERROR (parse failed)")
            return {
                'model': model['name'],
                'size_gb': model['size_gb'],
                'quantization': model['quant'],
                'tokens_generated': None,
                'total_time_s': None,
                'tokens_per_second': None,
                'time_to_first_token_ms': None,
                'status': 'parse_failed'
            }
            
    except subprocess.TimeoutExpired:
        print("TIMEOUT")
        return {
            'model': model['name'],
            'size_gb': model['size_gb'],
            'quantization': model['quant'],
            'tokens_generated': None,
            'total_time_s': None,
            'tokens_per_second': None,
            'time_to_first_token_ms': None,
            'status': 'timeout'
        }
    except Exception as e:
        if "out of memory" in str(e).lower() or "oom" in str(e).lower():
            print("OOM")
            status = 'oom'
        else:
            print(f"ERROR: {str(e)}")
            status = 'error'
        
        return {
            'model': model['name'],
            'size_gb': model['size_gb'],
            'quantization': model['quant'],
            'tokens_generated': None,
            'total_time_s': None,
            'tokens_per_second': None,
            'time_to_first_token_ms': None,
            'status': status
        }

def main():
    print("="*70)
    print("LLM Token Generation Benchmark")
    print("GamersNexus Methodology")
    print("="*70)
    print()
    
    # Check llama.cpp installation
    llama_dir = Path.home() / "llama.cpp"
    llama_cli = llama_dir / "llama-cli"
    
    if not llama_cli.exists():
        print("ERROR: llama.cpp not found!")
        print("Please run install_prerequisites.sh first")
        sys.exit(1)
    
    print(f"✓ llama.cpp found: {llama_cli}")
    
    # Get GPU info
    try:
        result = subprocess.run(['nvidia-smi', '--query-gpu=name,memory.total', '--format=csv,noheader'], 
                              capture_output=True, text=True, check=True)
        gpu_info = result.stdout.strip().split(', ')
        gpu_name = gpu_info[0]
        vram_mb = int(gpu_info[1].split()[0])
        vram_gb = vram_mb / 1024
        
        print(f"GPU: {gpu_name}")
        print(f"VRAM: {vram_gb:.1f} GB")
    except:
        print("WARNING: Could not detect GPU info")
        gpu_name = "Unknown"
        vram_gb = 0
    
    print()
    
    # Create models directory
    models_dir = llama_dir / "models"
    models_dir.mkdir(exist_ok=True)
    
    # Set GPU environment
    os.environ['CUDA_VISIBLE_DEVICES'] = '0'
    
    results = []
    
    for i, model in enumerate(MODELS, 1):
        print(f"\n[{i}/{len(MODELS)}] {model['name']} ({model['size_gb']:.1f}GB, {model['quant']})")
        print("-" * 70)
        
        # Check VRAM requirement
        if model['size_gb'] > vram_gb * 0.9:  # Leave 10% headroom
            print(f"  SKIP: Requires ~{model['size_gb']:.1f}GB, only {vram_gb:.1f}GB available")
            results.append({
                'model': model['name'],
                'size_gb': model['size_gb'],
                'quantization': model['quant'],
                'tokens_generated': None,
                'total_time_s': None,
                'tokens_per_second': None,
                'time_to_first_token_ms': None,
                'status': 'insufficient_vram'
            })
            continue
        
        # Download model
        model_path = download_model(model, models_dir)
        
        # Benchmark
        result = benchmark_model(model, model_path, llama_cli)
        results.append(result)
        
        # Small delay between models
        time.sleep(2)
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "llm_tokens_per_sec.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    
    # Save JSON
    json_file = output_dir / "llm_tokens_per_sec.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'prompt': PROMPT,
            'num_tokens': NUM_TOKENS,
            'results': results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("LLM Benchmark Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary:")
    print("-" * 70)
    for result in results:
        if result['status'] == 'success':
            print(f"{result['model']:30s} {result['tokens_per_second']:6.1f} t/s")
        else:
            print(f"{result['model']:30s} {result['status'].upper()}")

if __name__ == "__main__":
    main()
