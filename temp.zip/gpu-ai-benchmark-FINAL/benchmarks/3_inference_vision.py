#!/usr/bin/env python3
"""
Vision Inference Benchmark - ResNet-50 and ResNet-101
Tests inference latency and throughput
"""

import torch
import torchvision.models as models
import time
import json
import csv
import sys
from pathlib import Path

# Enable cudnn autotuner
torch.backends.cudnn.benchmark = True

# Configuration
MODELS = {
    'resnet50': models.resnet50,
    'resnet101': models.resnet101,
}

PRECISIONS = {
    'fp32': 'float',
    'fp16': 'half',
}

# Inference batch sizes (smaller than training)
BATCH_SIZES_BASE = [1, 8, 16, 32, 64]

NUM_WARMUP = 20
NUM_ITERATIONS = 200
IMAGE_SIZE = 224

def get_batch_sizes_for_vram(vram_gb):
    """Adjust batch sizes based on available VRAM"""
    if vram_gb >= 40:
        return [1, 8, 16, 32, 64, 128]
    elif vram_gb >= 24:
        return [1, 8, 16, 32, 64]
    elif vram_gb >= 16:
        return [1, 8, 16, 32]
    else:
        return [1, 4, 8, 16]

def benchmark_model(model_name, model_fn, precision_name, precision_fn, batch_size, device):
    """Benchmark a single model configuration"""
    
    print(f"  Testing: {model_name} {precision_name.upper()} BS={batch_size}...", end=' ', flush=True)
    
    try:
        # Create model
        model = model_fn(pretrained=False)
        model = getattr(model, precision_fn)()
        model = model.to(device)
        model.eval()  # Inference mode
        
        # Create dummy data
        if precision_fn == 'half':
            images = torch.randn(batch_size, 3, IMAGE_SIZE, IMAGE_SIZE, device=device).half()
        else:
            images = torch.randn(batch_size, 3, IMAGE_SIZE, IMAGE_SIZE, device=device)
        
        # Warmup
        with torch.no_grad():
            for _ in range(NUM_WARMUP):
                _ = model(images)
        
        torch.cuda.synchronize()
        
        # Benchmark
        times = []
        with torch.no_grad():
            for _ in range(NUM_ITERATIONS):
                start = time.time()
                _ = model(images)
                torch.cuda.synchronize()
                times.append(time.time() - start)
        
        avg_time = sum(times) / len(times)
        throughput = batch_size / avg_time
        latency = avg_time * 1000 / batch_size  # ms per image
        
        print(f"{throughput:.1f} img/s, {latency:.2f} ms/img")
        
        # Cleanup
        del model, images
        torch.cuda.empty_cache()
        
        return {
            'model': model_name,
            'precision': precision_name.upper(),
            'batch_size': batch_size,
            'avg_time_ms': avg_time * 1000,
            'latency_ms_per_image': latency,
            'throughput_img_per_sec': throughput,
            'status': 'success'
        }
        
    except RuntimeError as e:
        if "out of memory" in str(e):
            print(f"OOM")
            torch.cuda.empty_cache()
            return {
                'model': model_name,
                'precision': precision_name.upper(),
                'batch_size': batch_size,
                'avg_time_ms': None,
                'latency_ms_per_image': None,
                'throughput_img_per_sec': None,
                'status': 'oom'
            }
        else:
            print(f"ERROR: {str(e)}")
            raise

def main():
    print("="*70)
    print("Vision Inference Benchmark - ResNet Models")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    print()
    
    # Adjust batch sizes based on VRAM
    batch_sizes = get_batch_sizes_for_vram(vram_gb)
    print(f"Testing batch sizes: {batch_sizes}")
    print()
    
    results = []
    
    for model_name, model_fn in MODELS.items():
        print(f"\n{model_name.upper()}")
        print("-" * 70)
        
        for precision_name, precision_fn in PRECISIONS.items():
            for batch_size in batch_sizes:
                result = benchmark_model(
                    model_name, model_fn,
                    precision_name, precision_fn,
                    batch_size, device
                )
                results.append(result)
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "inference_vision.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    
    # Save JSON
    json_file = output_dir / "inference_vision.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'results': results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("Vision Inference Benchmark Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary (BS=1 Latency, Best Throughput):")
    print("-" * 70)
    for model_name in MODELS.keys():
        for precision_name in PRECISIONS.keys():
            # BS=1 latency
            bs1_results = [r for r in results if r['model'] == model_name and r['precision'] == precision_name.upper() and r['batch_size'] == 1 and r['status'] == 'success']
            if bs1_results:
                latency = bs1_results[0]['latency_ms_per_image']
                print(f"{model_name} {precision_name.upper()} (BS=1): {latency:.2f} ms/img latency")
            
            # Best throughput
            model_results = [r for r in results if r['model'] == model_name and r['precision'] == precision_name.upper() and r['status'] == 'success']
            if model_results:
                best = max(model_results, key=lambda x: x['throughput_img_per_sec'] if x['throughput_img_per_sec'] else 0)
                print(f"{model_name} {precision_name.upper()} (Best): {best['throughput_img_per_sec']:.1f} img/s (BS={best['batch_size']})")

if __name__ == "__main__":
    main()
