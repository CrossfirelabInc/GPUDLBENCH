#!/usr/bin/env python3
"""
Mixed Precision Speedup Analysis
Compares FP32 vs FP16 performance across multiple models
"""

import torch
import torchvision.models as models
from transformers import BertForSequenceClassification, BertConfig
import time
import json
import csv
import sys
from pathlib import Path

torch.backends.cudnn.benchmark = True

def benchmark_vision_mixed_precision(device):
    """Test FP32 vs FP16 speedup for vision models"""
    
    print("\n" + "="*70)
    print("Vision Models: FP32 vs FP16")
    print("="*70)
    print()
    
    results = []
    
    vision_models = {
        'resnet50': models.resnet50,
        'resnet101': models.resnet101,
    }
    
    batch_size = 32
    num_iterations = 100
    
    for model_name, model_fn in vision_models.items():
        print(f"{model_name}:")
        
        # FP32
        print(f"  FP32...", end=' ')
        model = model_fn(pretrained=False).float().to(device)
        model.train()
        
        images = torch.randn(batch_size, 3, 224, 224, device=device)
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        criterion = torch.nn.CrossEntropyLoss()
        targets = torch.randint(0, 1000, (batch_size,), device=device)
        
        # Warmup
        for _ in range(10):
            optimizer.zero_grad()
            loss = criterion(model(images), targets)
            loss.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        start = time.time()
        for _ in range(num_iterations):
            optimizer.zero_grad()
            loss = criterion(model(images), targets)
            loss.backward()
            optimizer.step()
        torch.cuda.synchronize()
        fp32_time = time.time() - start
        
        fp32_throughput = (batch_size * num_iterations) / fp32_time
        print(f"{fp32_throughput:.1f} img/s")
        
        del model, optimizer
        torch.cuda.empty_cache()
        
        # FP16
        print(f"  FP16...", end=' ')
        model = model_fn(pretrained=False).half().to(device)
        model.train()
        
        images = torch.randn(batch_size, 3, 224, 224, device=device).half()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        targets = torch.randint(0, 1000, (batch_size,), device=device)
        
        # Warmup
        for _ in range(10):
            optimizer.zero_grad()
            loss = criterion(model(images), targets)
            loss.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        start = time.time()
        for _ in range(num_iterations):
            optimizer.zero_grad()
            loss = criterion(model(images), targets)
            loss.backward()
            optimizer.step()
        torch.cuda.synchronize()
        fp16_time = time.time() - start
        
        fp16_throughput = (batch_size * num_iterations) / fp16_time
        speedup = fp16_time / fp32_time if fp32_time > 0 else 0
        speedup_ratio = fp32_time / fp16_time if fp16_time > 0 else 0
        
        print(f"{fp16_throughput:.1f} img/s ({speedup_ratio:.2f}x speedup)")
        
        results.append({
            'model_type': 'vision',
            'model': model_name,
            'fp32_throughput': fp32_throughput,
            'fp16_throughput': fp16_throughput,
            'speedup_ratio': speedup_ratio,
        })
        
        del model, optimizer
        torch.cuda.empty_cache()
    
    return results

def benchmark_nlp_mixed_precision(device):
    """Test FP32 vs FP16 speedup for NLP models"""
    
    print("\n" + "="*70)
    print("NLP Models: FP32 vs FP16")
    print("="*70)
    print()
    
    results = []
    
    nlp_configs = {
        'bert-base': {
            'hidden_size': 768,
            'num_hidden_layers': 12,
            'num_attention_heads': 12,
            'intermediate_size': 3072,
        },
    }
    
    batch_size = 16
    seq_length = 128
    num_iterations = 50
    
    for model_name, config_dict in nlp_configs.items():
        print(f"{model_name}:")
        
        config = BertConfig(
            vocab_size=30522,
            max_position_embeddings=512,
            num_labels=2,
            **config_dict
        )
        
        # FP32
        print(f"  FP32...", end=' ')
        model = BertForSequenceClassification(config).float().to(device)
        model.train()
        
        input_ids = torch.randint(0, 30522, (batch_size, seq_length), device=device)
        attention_mask = torch.ones(batch_size, seq_length, device=device)
        labels = torch.randint(0, 2, (batch_size,), device=device)
        optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
        
        # Warmup
        for _ in range(10):
            optimizer.zero_grad()
            loss = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels).loss
            loss.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        start = time.time()
        for _ in range(num_iterations):
            optimizer.zero_grad()
            loss = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels).loss
            loss.backward()
            optimizer.step()
        torch.cuda.synchronize()
        fp32_time = time.time() - start
        
        fp32_throughput = (batch_size * num_iterations) / fp32_time
        print(f"{fp32_throughput:.1f} samples/s")
        
        del model, optimizer
        torch.cuda.empty_cache()
        
        # FP16
        print(f"  FP16...", end=' ')
        model = BertForSequenceClassification(config).half().to(device)
        model.train()
        
        optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
        
        # Warmup
        for _ in range(10):
            optimizer.zero_grad()
            loss = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels).loss
            loss.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        start = time.time()
        for _ in range(num_iterations):
            optimizer.zero_grad()
            loss = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels).loss
            loss.backward()
            optimizer.step()
        torch.cuda.synchronize()
        fp16_time = time.time() - start
        
        fp16_throughput = (batch_size * num_iterations) / fp16_time
        speedup_ratio = fp32_time / fp16_time if fp16_time > 0 else 0
        
        print(f"{fp16_throughput:.1f} samples/s ({speedup_ratio:.2f}x speedup)")
        
        results.append({
            'model_type': 'nlp',
            'model': model_name,
            'fp32_throughput': fp32_throughput,
            'fp16_throughput': fp16_throughput,
            'speedup_ratio': speedup_ratio,
        })
        
        del model, optimizer
        torch.cuda.empty_cache()
    
    return results

def main():
    print("="*70)
    print("Mixed Precision Speedup Analysis")
    print("FP32 vs FP16 Performance Comparison")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    
    # Run benchmarks
    vision_results = benchmark_vision_mixed_precision(device)
    nlp_results = benchmark_nlp_mixed_precision(device)
    
    all_results = vision_results + nlp_results
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "mixed_precision.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=all_results[0].keys())
        writer.writeheader()
        writer.writerows(all_results)
    
    # Save JSON
    json_file = output_dir / "mixed_precision.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'results': all_results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("Mixed Precision Analysis Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary:")
    print("-" * 70)
    for result in all_results:
        print(f"{result['model']:20s} FP16 Speedup: {result['speedup_ratio']:.2f}x")
    
    avg_speedup = sum(r['speedup_ratio'] for r in all_results) / len(all_results)
    print(f"\nAverage FP16 Speedup: {avg_speedup:.2f}x")

if __name__ == "__main__":
    main()
