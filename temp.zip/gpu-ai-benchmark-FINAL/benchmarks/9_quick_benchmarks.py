#!/usr/bin/env python3
"""
Quick Benchmarks Collection
- AI-Benchmark
- PyTorch GPU Benchmark Suite
- TensorFlow Mixed Precision
- TensorFlow GPU Validation
"""

import subprocess
import sys
import json
from pathlib import Path

def run_ai_benchmark():
    """Run AI-Benchmark"""
    print("\n" + "="*70)
    print("Running AI-Benchmark")
    print("="*70)
    print()
    
    try:
        # Install if needed
        subprocess.run([sys.executable, '-m', 'pip', 'install', 'ai-benchmark', '--break-system-packages'], 
                      capture_output=True, check=True)
        
        # Run benchmark
        from ai_benchmark import AIBenchmark
        benchmark = AIBenchmark(use_CPU=False, verbose_level=2)
        results = benchmark.run()
        
        # Save results
        output_dir = Path("results")
        output_dir.mkdir(exist_ok=True)
        
        with open(output_dir / "ai_benchmark_results.json", 'w') as f:
            json.dump({
                'inference_score': results.inference_score,
                'training_score': results.training_score,
                'ai_score': results.ai_score,
            }, f, indent=2)
        
        print(f"\n✓ AI-Benchmark Score: {results.ai_score}")
        return True
        
    except Exception as e:
        print(f"✗ AI-Benchmark failed: {e}")
        return False

def run_pytorch_benchmark():
    """Run PyTorch GPU Benchmark Suite"""
    print("\n" + "="*70)
    print("Running PyTorch GPU Benchmark Suite")
    print("="*70)
    print()
    
    try:
        # Clone repo if not exists
        repo_dir = Path.home() / "pytorch-gpu-benchmark"
        if not repo_dir.exists():
            print("Cloning pytorch-gpu-benchmark...")
            subprocess.run([
                'git', 'clone', 
                'https://github.com/ryujaehun/pytorch-gpu-benchmark',
                str(repo_dir)
            ], check=True, capture_output=True)
        
        # Run benchmark
        print("Running benchmark (this may take 10-15 minutes)...")
        result = subprocess.run([
            sys.executable, str(repo_dir / 'pytorch_gpu_bench.py'),
            '--NUM_GPU', '1',
            '--BATCH_SIZE', '12',
            '--NUM_TEST', '20',
            '--folder', str(Path('results') / 'pytorch_bench')
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print("✓ PyTorch GPU Benchmark complete")
            print(f"  Results: results/pytorch_bench/")
            return True
        else:
            print(f"✗ PyTorch GPU Benchmark failed")
            print(result.stderr)
            return False
            
    except Exception as e:
        print(f"✗ PyTorch GPU Benchmark failed: {e}")
        return False

def run_tensorflow_tests():
    """Run TensorFlow GPU tests"""
    print("\n" + "="*70)
    print("Running TensorFlow Tests")
    print("="*70)
    print()
    
    try:
        # Install TensorFlow if needed
        print("Installing TensorFlow...")
        subprocess.run([
            sys.executable, '-m', 'pip', 'install', 
            'tensorflow[and-cuda]', '--break-system-packages'
        ], capture_output=True, check=True)
        
        # Test 1: GPU Detection
        print("\n1. Testing GPU detection...")
        import tensorflow as tf
        
        gpus = tf.config.list_physical_devices('GPU')
        if gpus:
            print(f"✓ TensorFlow detected {len(gpus)} GPU(s)")
            for gpu in gpus:
                print(f"  - {gpu}")
        else:
            print("✗ No GPUs detected by TensorFlow")
            return False
        
        # Test 2: Mixed Precision Performance
        print("\n2. Testing mixed precision performance...")
        
        # FP32
        with tf.device('/GPU:0'):
            model_fp32 = tf.keras.Sequential([
                tf.keras.layers.Dense(1024, activation='relu', input_shape=(1024,)),
                tf.keras.layers.Dense(1024, activation='relu'),
                tf.keras.layers.Dense(10, activation='softmax')
            ])
            model_fp32.compile(optimizer='adam', loss='sparse_categorical_crossentropy')
            
            x = tf.random.normal((128, 1024))
            y = tf.random.uniform((128,), maxval=10, dtype=tf.int32)
            
            import time
            start = time.time()
            for _ in range(100):
                model_fp32.fit(x, y, epochs=1, verbose=0)
            fp32_time = time.time() - start
        
        # FP16 Mixed Precision
        tf.keras.mixed_precision.set_global_policy('mixed_float16')
        
        with tf.device('/GPU:0'):
            model_fp16 = tf.keras.Sequential([
                tf.keras.layers.Dense(1024, activation='relu', input_shape=(1024,)),
                tf.keras.layers.Dense(1024, activation='relu'),
                tf.keras.layers.Dense(10, activation='softmax', dtype='float32')  # Keep output in FP32
            ])
            model_fp16.compile(optimizer='adam', loss='sparse_categorical_crossentropy')
            
            start = time.time()
            for _ in range(100):
                model_fp16.fit(x, y, epochs=1, verbose=0)
            fp16_time = time.time() - start
        
        speedup = fp32_time / fp16_time
        print(f"  FP32 time: {fp32_time:.2f}s")
        print(f"  FP16 time: {fp16_time:.2f}s")
        print(f"  Speedup: {speedup:.2f}x")
        
        # Save results
        output_dir = Path("results")
        output_dir.mkdir(exist_ok=True)
        
        with open(output_dir / "tensorflow_results.json", 'w') as f:
            json.dump({
                'gpu_detected': len(gpus),
                'fp32_time_s': fp32_time,
                'fp16_time_s': fp16_time,
                'mixed_precision_speedup': speedup
            }, f, indent=2)
        
        print("\n✓ TensorFlow tests complete")
        return True
        
    except Exception as e:
        print(f"✗ TensorFlow tests failed: {e}")
        return False

def main():
    print("="*70)
    print("Quick Benchmarks Collection")
    print("="*70)
    
    results = {
        'ai_benchmark': False,
        'pytorch_benchmark': False,
        'tensorflow': False,
    }
    
    # AI-Benchmark
    results['ai_benchmark'] = run_ai_benchmark()
    
    # PyTorch GPU Benchmark
    results['pytorch_benchmark'] = run_pytorch_benchmark()
    
    # TensorFlow tests
    results['tensorflow'] = run_tensorflow_tests()
    
    # Summary
    print("\n" + "="*70)
    print("Quick Benchmarks Summary")
    print("="*70)
    print()
    
    for test, success in results.items():
        status = "✓ PASS" if success else "✗ FAIL"
        print(f"{test:25s} {status}")
    
    print()

if __name__ == "__main__":
    main()
