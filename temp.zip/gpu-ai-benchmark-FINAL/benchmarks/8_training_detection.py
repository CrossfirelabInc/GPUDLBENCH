#!/usr/bin/env python3
"""
Object Detection Training Benchmark - Faster R-CNN
Alternative to Mask R-CNN (simpler, faster)
"""

import torch
import torchvision
from torchvision.models.detection import fasterrcnn_resnet50_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
import time
import json
import csv
import sys
from pathlib import Path

torch.backends.cudnn.benchmark = True

# Configuration
PRECISIONS = {
    'fp32': 'float',
    'fp16': 'half',
}

NUM_WARMUP = 5
NUM_ITERATIONS = 50
NUM_CLASSES = 91  # COCO classes
IMAGE_SIZE = 800

def get_batch_sizes_for_vram(vram_gb):
    """Adjust batch sizes based on available VRAM"""
    if vram_gb >= 40:
        return [2, 4, 8]
    elif vram_gb >= 24:
        return [1, 2, 4]
    elif vram_gb >= 16:
        return [1, 2]
    else:
        return [1]

def benchmark_model(precision_name, precision_fn, batch_size, device):
    """Benchmark Faster R-CNN"""
    
    print(f"  Testing: Faster R-CNN {precision_name.upper()} BS={batch_size}...", end=' ', flush=True)
    
    try:
        # Create model
        model = fasterrcnn_resnet50_fpn(pretrained=False, num_classes=NUM_CLASSES)
        model = getattr(model, precision_fn)()
        model = model.to(device)
        model.train()
        
        # Create optimizer
        params = [p for p in model.parameters() if p.requires_grad]
        optimizer = torch.optim.SGD(params, lr=0.005, momentum=0.9, weight_decay=0.0005)
        
        # Create dummy data
        images = []
        targets = []
        for _ in range(batch_size):
            if precision_fn == 'half':
                img = torch.randn(3, IMAGE_SIZE, IMAGE_SIZE, device=device).half()
            else:
                img = torch.randn(3, IMAGE_SIZE, IMAGE_SIZE, device=device)
            images.append(img)
            
            # Create dummy targets
            num_boxes = 5
            boxes = torch.rand(num_boxes, 4, device=device) * IMAGE_SIZE
            boxes[:, 2:] += boxes[:, :2]  # x2, y2 = x1 + w, y1 + h
            
            targets.append({
                'boxes': boxes,
                'labels': torch.randint(1, NUM_CLASSES, (num_boxes,), device=device)
            })
        
        # Warmup
        for _ in range(NUM_WARMUP):
            optimizer.zero_grad()
            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())
            losses.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        times = []
        for _ in range(NUM_ITERATIONS):
            start = time.time()
            optimizer.zero_grad()
            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())
            losses.backward()
            optimizer.step()
            torch.cuda.synchronize()
            times.append(time.time() - start)
        
        avg_time = sum(times) / len(times)
        throughput = batch_size / avg_time
        
        print(f"{throughput:.2f} img/s")
        
        # Cleanup
        del model, optimizer, images, targets
        torch.cuda.empty_cache()
        
        return {
            'model': 'faster-rcnn-resnet50',
            'precision': precision_name.upper(),
            'batch_size': batch_size,
            'avg_time_ms': avg_time * 1000,
            'throughput_img_per_sec': throughput,
            'status': 'success'
        }
        
    except RuntimeError as e:
        if "out of memory" in str(e):
            print(f"OOM")
            torch.cuda.empty_cache()
            return {
                'model': 'faster-rcnn-resnet50',
                'precision': precision_name.upper(),
                'batch_size': batch_size,
                'avg_time_ms': None,
                'throughput_img_per_sec': None,
                'status': 'oom'
            }
        else:
            print(f"ERROR: {str(e)}")
            raise

def main():
    print("="*70)
    print("Object Detection Training Benchmark - Faster R-CNN")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    print()
    
    # Adjust batch sizes based on VRAM
    batch_sizes = get_batch_sizes_for_vram(vram_gb)
    print(f"Testing batch sizes: {batch_sizes}")
    print()
    
    results = []
    
    print("FASTER R-CNN")
    print("-" * 70)
    
    for precision_name, precision_fn in PRECISIONS.items():
        for batch_size in batch_sizes:
            result = benchmark_model(precision_name, precision_fn, batch_size, device)
            results.append(result)
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "training_detection.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    
    # Save JSON
    json_file = output_dir / "training_detection.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'results': results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("Object Detection Training Benchmark Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary (Best Results):")
    print("-" * 70)
    for precision_name in PRECISIONS.keys():
        model_results = [r for r in results if r['precision'] == precision_name.upper() and r['status'] == 'success']
        if model_results:
            best = max(model_results, key=lambda x: x['throughput_img_per_sec'] if x['throughput_img_per_sec'] else 0)
            print(f"Faster R-CNN {precision_name.upper()}: {best['throughput_img_per_sec']:.2f} img/s (BS={best['batch_size']})")

if __name__ == "__main__":
    main()
