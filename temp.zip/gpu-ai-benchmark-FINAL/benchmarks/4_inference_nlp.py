#!/usr/bin/env python3
"""
NLP Inference Benchmark - BERT-base and BERT-large
Tests inference latency and throughput
"""

import torch
from transformers import BertForSequenceClassification, BertConfig
import time
import json
import csv
import sys
from pathlib import Path

# Enable cudnn autotuner
torch.backends.cudnn.benchmark = True

# Configuration
MODELS = {
    'bert-base': {
        'hidden_size': 768,
        'num_hidden_layers': 12,
        'num_attention_heads': 12,
        'intermediate_size': 3072,
    },
    'bert-large': {
        'hidden_size': 1024,
        'num_hidden_layers': 24,
        'num_attention_heads': 16,
        'intermediate_size': 4096,
    },
}

PRECISIONS = {
    'fp32': 'float',
    'fp16': 'half',
}

SEQ_LENGTH = 128
NUM_WARMUP = 20
NUM_ITERATIONS = 200
NUM_LABELS = 2

def get_batch_sizes_for_vram(vram_gb, model_name):
    """Adjust batch sizes based on available VRAM and model size"""
    if model_name == 'bert-base':
        if vram_gb >= 40:
            return [1, 8, 16, 32, 64]
        elif vram_gb >= 24:
            return [1, 8, 16, 32]
        elif vram_gb >= 16:
            return [1, 4, 8, 16]
        else:
            return [1, 2, 4, 8]
    else:  # bert-large
        if vram_gb >= 40:
            return [1, 4, 8, 16, 32]
        elif vram_gb >= 24:
            return [1, 4, 8, 16]
        elif vram_gb >= 16:
            return [1, 2, 4, 8]
        else:
            return [1, 2, 4]

def benchmark_model(model_name, model_config, precision_name, precision_fn, batch_size, device):
    """Benchmark a single model configuration"""
    
    print(f"  Testing: {model_name} {precision_name.upper()} BS={batch_size}...", end=' ', flush=True)
    
    try:
        # Create model
        config = BertConfig(
            vocab_size=30522,
            max_position_embeddings=512,
            num_labels=NUM_LABELS,
            **model_config
        )
        
        model = BertForSequenceClassification(config)
        model = getattr(model, precision_fn)()
        model = model.to(device)
        model.eval()  # Inference mode
        
        # Create dummy data
        input_ids = torch.randint(0, config.vocab_size, (batch_size, SEQ_LENGTH), device=device)
        attention_mask = torch.ones(batch_size, SEQ_LENGTH, device=device)
        
        # Warmup
        with torch.no_grad():
            for _ in range(NUM_WARMUP):
                _ = model(input_ids=input_ids, attention_mask=attention_mask)
        
        torch.cuda.synchronize()
        
        # Benchmark
        times = []
        with torch.no_grad():
            for _ in range(NUM_ITERATIONS):
                start = time.time()
                _ = model(input_ids=input_ids, attention_mask=attention_mask)
                torch.cuda.synchronize()
                times.append(time.time() - start)
        
        avg_time = sum(times) / len(times)
        throughput = batch_size / avg_time
        latency = avg_time * 1000 / batch_size  # ms per sample
        
        print(f"{throughput:.1f} samples/s, {latency:.2f} ms/sample")
        
        # Cleanup
        del model, input_ids, attention_mask
        torch.cuda.empty_cache()
        
        return {
            'model': model_name,
            'precision': precision_name.upper(),
            'batch_size': batch_size,
            'seq_length': SEQ_LENGTH,
            'avg_time_ms': avg_time * 1000,
            'latency_ms_per_sample': latency,
            'throughput_samples_per_sec': throughput,
            'status': 'success'
        }
        
    except RuntimeError as e:
        if "out of memory" in str(e):
            print(f"OOM")
            torch.cuda.empty_cache()
            return {
                'model': model_name,
                'precision': precision_name.upper(),
                'batch_size': batch_size,
                'seq_length': SEQ_LENGTH,
                'avg_time_ms': None,
                'latency_ms_per_sample': None,
                'throughput_samples_per_sec': None,
                'status': 'oom'
            }
        else:
            print(f"ERROR: {str(e)}")
            raise

def main():
    print("="*70)
    print("NLP Inference Benchmark - BERT Models")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    print(f"Sequence Length: {SEQ_LENGTH}")
    print()
    
    results = []
    
    for model_name, model_config in MODELS.items():
        batch_sizes = get_batch_sizes_for_vram(vram_gb, model_name)
        
        print(f"\n{model_name.upper()}")
        print(f"Batch sizes: {batch_sizes}")
        print("-" * 70)
        
        for precision_name, precision_fn in PRECISIONS.items():
            for batch_size in batch_sizes:
                result = benchmark_model(
                    model_name, model_config,
                    precision_name, precision_fn,
                    batch_size, device
                )
                results.append(result)
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "inference_nlp.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    
    # Save JSON
    json_file = output_dir / "inference_nlp.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'results': results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("NLP Inference Benchmark Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary (BS=1 Latency, Best Throughput):")
    print("-" * 70)
    for model_name in MODELS.keys():
        for precision_name in PRECISIONS.keys():
            # BS=1 latency
            bs1_results = [r for r in results if r['model'] == model_name and r['precision'] == precision_name.upper() and r['batch_size'] == 1 and r['status'] == 'success']
            if bs1_results:
                latency = bs1_results[0]['latency_ms_per_sample']
                print(f"{model_name} {precision_name.upper()} (BS=1): {latency:.2f} ms/sample latency")
            
            # Best throughput
            model_results = [r for r in results if r['model'] == model_name and r['precision'] == precision_name.upper() and r['status'] == 'success']
            if model_results:
                best = max(model_results, key=lambda x: x['throughput_samples_per_sec'] if x['throughput_samples_per_sec'] else 0)
                print(f"{model_name} {precision_name.upper()} (Best): {best['throughput_samples_per_sec']:.1f} samples/s (BS={best['batch_size']})")

if __name__ == "__main__":
    main()
