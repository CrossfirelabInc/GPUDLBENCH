#!/usr/bin/env python3
"""
VRAM Limitation Test
Demonstrates what different VRAM capacities can/cannot do
Shows 24GB vs 32GB vs 48GB practical limits
"""

import torch
from transformers import AutoModelForCausalLM, AutoConfig
import json
import csv
import sys
from pathlib import Path

def test_model_size_limit(vram_gb, device):
    """Test maximum model size that can be loaded"""
    
    print("\n" + "="*70)
    print("Test 1: Maximum Model Size")
    print("="*70)
    print()
    
    # Test progressive model sizes (in billions of parameters)
    test_sizes = [7, 13, 20, 30, 40, 70]
    
    results = []
    max_size = 0
    
    for size in test_sizes:
        # Estimate VRAM needed (rough): size_B * 2 bytes (FP16) * 1.2 (overhead)
        estimated_vram = size * 2 * 1.2 / 1024  # GB
        
        print(f"  Testing {size}B model (~{estimated_vram:.1f}GB VRAM)...", end=' ')
        
        if estimated_vram > vram_gb * 0.95:
            print(f"SKIP (exceeds {vram_gb:.1f}GB)")
            results.append({
                'size_billions': size,
                'estimated_vram_gb': estimated_vram,
                'loadable': False,
                'reason': 'insufficient_vram'
            })
            continue
        
        try:
            # Create a model configuration with specified size
            config = AutoConfig.from_pretrained(
                "gpt2",
                num_hidden_layers=int(size * 2),  # Scale layers with size
                hidden_size=768 if size < 20 else 1024,
                num_attention_heads=12 if size < 20 else 16,
            )
            
            model = AutoModelForCausalLM.from_config(config)
            model = model.half().to(device)
            
            # Get actual VRAM used
            actual_vram = torch.cuda.memory_allocated(device) / (1024**3)
            
            print(f"SUCCESS ({actual_vram:.1f}GB used)")
            
            results.append({
                'size_billions': size,
                'estimated_vram_gb': estimated_vram,
                'actual_vram_gb': actual_vram,
                'loadable': True,
                'reason': 'success'
            })
            
            max_size = size
            
            # Cleanup
            del model
            torch.cuda.empty_cache()
            
        except RuntimeError as e:
            if "out of memory" in str(e):
                print("OOM")
                results.append({
                    'size_billions': size,
                    'estimated_vram_gb': estimated_vram,
                    'loadable': False,
                    'reason': 'oom'
                })
                torch.cuda.empty_cache()
                break
            else:
                raise
    
    return results, max_size

def test_context_length_limit(vram_gb, device):
    """Test maximum context length for a given model size"""
    
    print("\n" + "="*70)
    print("Test 2: Maximum Context Length (7B Model)")
    print("="*70)
    print()
    
    # Use a 7B-scale model
    config = AutoConfig.from_pretrained(
        "gpt2",
        num_hidden_layers=24,
        hidden_size=768,
        num_attention_heads=12,
    )
    
    model = AutoModelForCausalLM.from_config(config)
    model = model.half().to(device)
    
    # Test progressive context lengths
    context_lengths = [1024, 2048, 4096, 8192, 16384, 32768, 65536, 131072]
    
    results = []
    max_context = 0
    
    for context in context_lengths:
        print(f"  Testing context length {context}...", end=' ')
        
        try:
            # Create dummy input
            input_ids = torch.randint(0, 50257, (1, context), device=device)
            
            # Forward pass
            with torch.no_grad():
                _ = model(input_ids)
            
            actual_vram = torch.cuda.memory_allocated(device) / (1024**3)
            
            print(f"SUCCESS ({actual_vram:.1f}GB used)")
            
            results.append({
                'context_length': context,
                'vram_used_gb': actual_vram,
                'success': True
            })
            
            max_context = context
            
            # Cleanup
            del input_ids
            torch.cuda.empty_cache()
            
        except RuntimeError as e:
            if "out of memory" in str(e):
                print("OOM")
                results.append({
                    'context_length': context,
                    'vram_used_gb': None,
                    'success': False
                })
                torch.cuda.empty_cache()
                break
            else:
                raise
    
    # Cleanup
    del model
    torch.cuda.empty_cache()
    
    return results, max_context

def test_multi_model_deployment(vram_gb, device):
    """Test how many models can be loaded simultaneously"""
    
    print("\n" + "="*70)
    print("Test 3: Multi-Model Deployment (7B Models)")
    print("="*70)
    print()
    
    config = AutoConfig.from_pretrained(
        "gpt2",
        num_hidden_layers=24,
        hidden_size=768,
        num_attention_heads=12,
    )
    
    models = []
    max_models = 0
    
    for i in range(1, 10):
        print(f"  Loading model {i}...", end=' ')
        
        try:
            model = AutoModelForCausalLM.from_config(config)
            model = model.half().to(device)
            models.append(model)
            
            actual_vram = torch.cuda.memory_allocated(device) / (1024**3)
            print(f"SUCCESS ({actual_vram:.1f}GB total)")
            
            max_models = i
            
        except RuntimeError as e:
            if "out of memory" in str(e):
                print("OOM")
                torch.cuda.empty_cache()
                break
            else:
                raise
    
    # Cleanup
    for model in models:
        del model
    torch.cuda.empty_cache()
    
    return max_models

def main():
    print("="*70)
    print("VRAM Limitation Tests")
    print("Demonstrates 24GB vs 32GB vs 48GB practical limits")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    
    # Test 1: Maximum model size
    model_size_results, max_model_size = test_model_size_limit(vram_gb, device)
    
    # Test 2: Maximum context length
    context_results, max_context = test_context_length_limit(vram_gb, device)
    
    # Test 3: Multi-model deployment
    max_models = test_multi_model_deployment(vram_gb, device)
    
    # Compile results
    summary = {
        'gpu': gpu_name,
        'vram_gb': vram_gb,
        'max_model_size_billions': max_model_size,
        'max_context_length': max_context,
        'max_simultaneous_7b_models': max_models,
        'model_size_tests': model_size_results,
        'context_length_tests': context_results,
    }
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save JSON
    json_file = output_dir / "vram_limits.json"
    with open(json_file, 'w') as f:
        json.dump(summary, f, indent=2)
    
    # Save CSV (model size tests)
    csv_file = output_dir / "vram_limits_models.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['size_billions', 'estimated_vram_gb', 'loadable', 'reason'])
        writer.writeheader()
        for result in model_size_results:
            writer.writerow({
                'size_billions': result['size_billions'],
                'estimated_vram_gb': result['estimated_vram_gb'],
                'loadable': result['loadable'],
                'reason': result['reason']
            })
    
    print("\n" + "="*70)
    print("VRAM Limitation Tests Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {json_file}")
    print(f"  - {csv_file}")
    print()
    
    # Print summary
    print("Summary:")
    print("-" * 70)
    print(f"Maximum Model Size: ~{max_model_size}B parameters")
    print(f"Maximum Context (7B model): {max_context} tokens")
    print(f"Simultaneous 7B Models: {max_models}")
    print()
    
    # Comparison to reference GPUs
    print("Comparison to Reference GPUs:")
    print("-" * 70)
    print("RTX A5000 (24GB):")
    print("  - Max model: ~30B Q4")
    print("  - Max context (7B): ~16K tokens")
    print("  - Simultaneous 7B models: 2-3")
    print()
    print("RTX 5090 (32GB):")
    print("  - Max model: ~70B Q4 (tight)")
    print("  - Max context (7B): ~32K tokens")
    print("  - Simultaneous 7B models: 4-5")
    print()
    print("RTX 5000 Blackwell (48GB):")
    print("  - Max model: ~70B Q5/Q6")
    print("  - Max context (7B): ~128K tokens")
    print("  - Simultaneous 7B models: 6-7")

if __name__ == "__main__":
    main()
