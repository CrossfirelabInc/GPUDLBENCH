#!/usr/bin/env python3
"""
NLP Training Benchmark - BERT-base and BERT-large
Based on Lambda Labs methodology
"""

import torch
from transformers import BertForSequenceClassification, BertConfig
import time
import json
import csv
import sys
from pathlib import Path

# Enable cudnn autotuner
torch.backends.cudnn.benchmark = True

# Configuration
MODELS = {
    'bert-base': {
        'hidden_size': 768,
        'num_hidden_layers': 12,
        'num_attention_heads': 12,
        'intermediate_size': 3072,
    },
    'bert-large': {
        'hidden_size': 1024,
        'num_hidden_layers': 24,
        'num_attention_heads': 16,
        'intermediate_size': 4096,
    },
}

PRECISIONS = {
    'fp32': 'float',
    'fp16': 'half',
}

# Batch sizes to test (will auto-adjust based on VRAM)
SEQ_LENGTH = 128
NUM_WARMUP = 10
NUM_ITERATIONS = 50
NUM_LABELS = 2

def get_batch_sizes_for_vram(vram_gb, model_name):
    """Adjust batch sizes based on available VRAM and model size"""
    if model_name == 'bert-base':
        if vram_gb >= 40:
            return [8, 16, 32, 64]
        elif vram_gb >= 24:
            return [8, 16, 32]
        elif vram_gb >= 16:
            return [4, 8, 16]
        else:
            return [2, 4, 8]
    else:  # bert-large
        if vram_gb >= 40:
            return [4, 8, 16, 32]
        elif vram_gb >= 24:
            return [2, 4, 8]
        elif vram_gb >= 16:
            return [2, 4]
        else:
            return [1, 2]

def benchmark_model(model_name, model_config, precision_name, precision_fn, batch_size, device):
    """Benchmark a single model configuration"""
    
    print(f"  Testing: {model_name} {precision_name.upper()} BS={batch_size}...", end=' ', flush=True)
    
    try:
        # Create model
        config = BertConfig(
            vocab_size=30522,
            max_position_embeddings=512,
            num_labels=NUM_LABELS,
            **model_config
        )
        
        model = BertForSequenceClassification(config)
        model = getattr(model, precision_fn)()
        model = model.to(device)
        model.train()
        
        # Create optimizer
        optimizer = torch.optim.AdamW(model.parameters(), lr=5e-5)
        
        # Create dummy data
        input_ids = torch.randint(0, config.vocab_size, (batch_size, SEQ_LENGTH), device=device)
        attention_mask = torch.ones(batch_size, SEQ_LENGTH, device=device)
        labels = torch.randint(0, NUM_LABELS, (batch_size,), device=device)
        
        # Warmup
        for _ in range(NUM_WARMUP):
            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
        
        torch.cuda.synchronize()
        
        # Benchmark
        times = []
        for _ in range(NUM_ITERATIONS):
            start = time.time()
            optimizer.zero_grad()
            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            torch.cuda.synchronize()
            times.append(time.time() - start)
        
        avg_time = sum(times) / len(times)
        throughput = batch_size / avg_time
        
        print(f"{throughput:.1f} samples/s")
        
        # Cleanup
        del model, optimizer, input_ids, attention_mask, labels
        torch.cuda.empty_cache()
        
        return {
            'model': model_name,
            'precision': precision_name.upper(),
            'batch_size': batch_size,
            'seq_length': SEQ_LENGTH,
            'avg_time_ms': avg_time * 1000,
            'throughput_samples_per_sec': throughput,
            'status': 'success'
        }
        
    except RuntimeError as e:
        if "out of memory" in str(e):
            print(f"OOM")
            torch.cuda.empty_cache()
            return {
                'model': model_name,
                'precision': precision_name.upper(),
                'batch_size': batch_size,
                'seq_length': SEQ_LENGTH,
                'avg_time_ms': None,
                'throughput_samples_per_sec': None,
                'status': 'oom'
            }
        else:
            print(f"ERROR: {str(e)}")
            raise

def main():
    print("="*70)
    print("NLP Training Benchmark - BERT Models")
    print("="*70)
    print()
    
    # Check CUDA
    if not torch.cuda.is_available():
        print("ERROR: CUDA not available!")
        sys.exit(1)
    
    device = torch.device("cuda:0")
    gpu_name = torch.cuda.get_device_name(0)
    vram_gb = torch.cuda.get_device_properties(0).total_memory / (1024**3)
    
    print(f"GPU: {gpu_name}")
    print(f"VRAM: {vram_gb:.1f} GB")
    print(f"Sequence Length: {SEQ_LENGTH}")
    print()
    
    results = []
    
    for model_name, model_config in MODELS.items():
        batch_sizes = get_batch_sizes_for_vram(vram_gb, model_name)
        
        print(f"\n{model_name.upper()}")
        print(f"Batch sizes: {batch_sizes}")
        print("-" * 70)
        
        for precision_name, precision_fn in PRECISIONS.items():
            for batch_size in batch_sizes:
                result = benchmark_model(
                    model_name, model_config,
                    precision_name, precision_fn,
                    batch_size, device
                )
                results.append(result)
    
    # Save results
    output_dir = Path("results")
    output_dir.mkdir(exist_ok=True)
    
    # Save CSV
    csv_file = output_dir / "training_nlp.csv"
    with open(csv_file, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)
    
    # Save JSON
    json_file = output_dir / "training_nlp.json"
    with open(json_file, 'w') as f:
        json.dump({
            'gpu': gpu_name,
            'vram_gb': vram_gb,
            'results': results
        }, f, indent=2)
    
    print("\n" + "="*70)
    print("NLP Training Benchmark Complete!")
    print("="*70)
    print(f"\nResults saved to:")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()
    
    # Print summary
    print("Summary (Best Results):")
    print("-" * 70)
    for model_name in MODELS.keys():
        for precision_name in PRECISIONS.keys():
            model_results = [r for r in results if r['model'] == model_name and r['precision'] == precision_name.upper() and r['status'] == 'success']
            if model_results:
                best = max(model_results, key=lambda x: x['throughput_samples_per_sec'] if x['throughput_samples_per_sec'] else 0)
                print(f"{model_name} {precision_name.upper()}: {best['throughput_samples_per_sec']:.1f} samples/s (BS={best['batch_size']})")

if __name__ == "__main__":
    main()
