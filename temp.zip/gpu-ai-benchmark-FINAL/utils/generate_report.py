#!/usr/bin/env python3
"""
Report Generator
Creates comprehensive benchmark summary report
"""

import json
import csv
from pathlib import Path
from datetime import datetime

# Reference scores for comparison
REFERENCE_GPUS = {
    'RTX 5090': {
        'vram': 32,
        'dlperf': 74,
        'resnet50_fp32': 750,
        'resnet50_fp16': 1500,
        'bert_base_fp32': 200,
        'llm_7b': 80,
        'llm_70b_q4': 13,
    },
    'RTX 5000 Blackwell': {
        'vram': 48,
        'dlperf': 50,
        'resnet50_fp32': 520,
        'resnet50_fp16': 1040,
        'bert_base_fp32': 140,
        'llm_7b': 55,
        'llm_70b_q4': 28,
    },
    'RTX 4090': {
        'vram': 24,
        'dlperf': 62,
        'resnet50_fp32': 650,
        'resnet50_fp16': 1300,
        'bert_base_fp32': 180,
        'llm_7b': 70,
        'llm_70b_q4': 'N/A',
    },
    'RTX A5000': {
        'vram': 24,
        'dlperf': 34,
        'resnet50_fp32': 450,
        'resnet50_fp16': 900,
        'bert_base_fp32': 120,
        'llm_7b': 55,
        'llm_70b_q4': 'FAIL',
    },
}

def load_results():
    """Load all benchmark results"""
    results_dir = Path("results")
    
    data = {}
    
    # Load training vision
    try:
        with open(results_dir / "training_vision.json") as f:
            data['training_vision'] = json.load(f)
    except:
        data['training_vision'] = None
    
    # Load training NLP
    try:
        with open(results_dir / "training_nlp.json") as f:
            data['training_nlp'] = json.load(f)
    except:
        data['training_nlp'] = None
    
    # Load inference vision
    try:
        with open(results_dir / "inference_vision.json") as f:
            data['inference_vision'] = json.load(f)
    except:
        data['inference_vision'] = None
    
    # Load inference NLP
    try:
        with open(results_dir / "inference_nlp.json") as f:
            data['inference_nlp'] = json.load(f)
    except:
        data['inference_nlp'] = None
    
    # Load LLM
    try:
        with open(results_dir / "llm_tokens_per_sec.json") as f:
            data['llm'] = json.load(f)
    except:
        data['llm'] = None
    
    # Load VRAM limits
    try:
        with open(results_dir / "vram_limits.json") as f:
            data['vram_limits'] = json.load(f)
    except:
        data['vram_limits'] = None
    
    # Load mixed precision
    try:
        with open(results_dir / "mixed_precision.json") as f:
            data['mixed_precision'] = json.load(f)
    except:
        data['mixed_precision'] = None
    
    return data

def generate_markdown_report(data):
    """Generate Markdown summary report"""
    
    # Get GPU info
    gpu_name = "Unknown GPU"
    vram_gb = 0
    
    for test_data in data.values():
        if test_data and 'gpu' in test_data:
            gpu_name = test_data['gpu']
            vram_gb = test_data.get('vram_gb', 0)
            break
    
    report = []
    report.append("# GPU AI Benchmark Results\n")
    report.append(f"**GPU**: {gpu_name}\n")
    report.append(f"**VRAM**: {vram_gb:.1f} GB\n")
    report.append(f"**Date**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    report.append("\n---\n\n")
    
    # Training Performance
    report.append("## Training Performance\n\n")
    
    if data['training_vision']:
        report.append("### Vision Models\n\n")
        report.append("| Model | Precision | Best Throughput | Batch Size |\n")
        report.append("|-------|-----------|-----------------|------------|\n")
        
        for model in ['resnet50', 'resnet101']:
            for precision in ['FP32', 'FP16']:
                results = [r for r in data['training_vision']['results'] 
                          if r['model'] == model and r['precision'] == precision and r['status'] == 'success']
                if results:
                    best = max(results, key=lambda x: x.get('throughput_img_per_sec', 0))
                    report.append(f"| {model} | {precision} | {best['throughput_img_per_sec']:.1f} img/s | {best['batch_size']} |\n")
        report.append("\n")
    
    if data['training_nlp']:
        report.append("### NLP Models\n\n")
        report.append("| Model | Precision | Best Throughput | Batch Size |\n")
        report.append("|-------|-----------|-----------------|------------|\n")
        
        for model in ['bert-base', 'bert-large']:
            for precision in ['FP32', 'FP16']:
                results = [r for r in data['training_nlp']['results'] 
                          if r['model'] == model and r['precision'] == precision and r['status'] == 'success']
                if results:
                    best = max(results, key=lambda x: x.get('throughput_samples_per_sec', 0))
                    report.append(f"| {model} | {precision} | {best['throughput_samples_per_sec']:.1f} samples/s | {best['batch_size']} |\n")
        report.append("\n")
    
    # LLM Performance
    if data['llm']:
        report.append("## LLM Performance (Tokens/Second)\n\n")
        report.append("| Model | Size | Quantization | Tokens/sec | Status |\n")
        report.append("|-------|------|--------------|------------|--------|\n")
        
        for result in data['llm']['results']:
            tokens_per_sec = result.get('tokens_per_second')
            if tokens_per_sec:
                report.append(f"| {result['model']} | {result['size_gb']:.1f}GB | {result['quantization']} | {tokens_per_sec:.1f} | {result['status']} |\n")
            else:
                report.append(f"| {result['model']} | {result['size_gb']:.1f}GB | {result['quantization']} | - | {result['status'].upper()} |\n")
        report.append("\n")
    
    # VRAM Limits
    if data['vram_limits']:
        report.append("## VRAM Capabilities\n\n")
        report.append(f"- **Maximum Model Size**: ~{data['vram_limits']['max_model_size_billions']}B parameters\n")
        report.append(f"- **Maximum Context Length** (7B model): {data['vram_limits']['max_context_length']:,} tokens\n")
        report.append(f"- **Simultaneous 7B Models**: {data['vram_limits']['max_simultaneous_7b_models']}\n")
        report.append("\n")
    
    # Mixed Precision
    if data['mixed_precision']:
        report.append("## Mixed Precision Speedup\n\n")
        report.append("| Model | FP16 Speedup |\n")
        report.append("|-------|-------------|\n")
        
        for result in data['mixed_precision']['results']:
            report.append(f"| {result['model']} | {result['speedup_ratio']:.2f}x |\n")
        
        avg_speedup = sum(r['speedup_ratio'] for r in data['mixed_precision']['results']) / len(data['mixed_precision']['results'])
        report.append(f"\n**Average FP16 Speedup**: {avg_speedup:.2f}x\n\n")
    
    # DLPerf Estimate
    if data['training_vision']:
        resnet50_fp32_results = [r for r in data['training_vision']['results'] 
                                  if r['model'] == 'resnet50' and r['precision'] == 'FP32' and r['status'] == 'success']
        if resnet50_fp32_results:
            best_resnet = max(resnet50_fp32_results, key=lambda x: x.get('throughput_img_per_sec', 0))
            throughput = best_resnet['throughput_img_per_sec']
            dlperf_estimate = throughput / 13.0
            
            report.append("## DLPerf Score (Estimated)\n\n")
            report.append(f"Based on ResNet-50 FP32 training throughput ({throughput:.1f} img/s):\n\n")
            report.append(f"**Estimated DLPerf**: {dlperf_estimate:.1f}\n\n")
    
    # Comparison to Reference GPUs
    report.append("---\n\n")
    report.append("## Comparison to Reference GPUs\n\n")
    report.append("| GPU | VRAM | DLPerf | ResNet-50 FP32 | BERT-base FP32 | 70B Q4 |\n")
    report.append("|-----|------|--------|----------------|----------------|--------|\n")
    
    for gpu_name_ref, specs in REFERENCE_GPUS.items():
        report.append(f"| {gpu_name_ref} | {specs['vram']}GB | {specs['dlperf']} | {specs['resnet50_fp32']} img/s | {specs['bert_base_fp32']} s/s | {specs['llm_70b_q4']} |\n")
    
    report.append("\n---\n\n")
    report.append("*Report generated by GPU AI Benchmark Suite*\n")
    
    return ''.join(report)

def generate_csv_summary(data):
    """Generate CSV summary for easy comparison"""
    
    # Get GPU info
    gpu_name = "Unknown"
    vram_gb = 0
    
    for test_data in data.values():
        if test_data and 'gpu' in test_data:
            gpu_name = test_data['gpu']
            vram_gb = test_data.get('vram_gb', 0)
            break
    
    rows = []
    
    # Add header row
    rows.append({
        'gpu': gpu_name,
        'vram_gb': vram_gb,
        'test_type': 'GPU Info',
        'metric': 'VRAM',
        'value': f"{vram_gb:.1f} GB"
    })
    
    # Add training results
    if data['training_vision']:
        for model in ['resnet50', 'resnet101']:
            for precision in ['FP32', 'FP16']:
                results = [r for r in data['training_vision']['results'] 
                          if r['model'] == model and r['precision'] == precision and r['status'] == 'success']
                if results:
                    best = max(results, key=lambda x: x.get('throughput_img_per_sec', 0))
                    rows.append({
                        'gpu': gpu_name,
                        'vram_gb': vram_gb,
                        'test_type': 'Training Vision',
                        'metric': f"{model} {precision}",
                        'value': f"{best['throughput_img_per_sec']:.1f} img/s"
                    })
    
    # Add LLM results
    if data['llm']:
        for result in data['llm']['results']:
            if result.get('tokens_per_second'):
                rows.append({
                    'gpu': gpu_name,
                    'vram_gb': vram_gb,
                    'test_type': 'LLM',
                    'metric': result['model'],
                    'value': f"{result['tokens_per_second']:.1f} t/s"
                })
    
    return rows

def main():
    print("="*70)
    print("Generating Benchmark Report")
    print("="*70)
    print()
    
    # Load results
    print("Loading results...")
    data = load_results()
    
    results_dir = Path("results")
    results_dir.mkdir(exist_ok=True)
    
    # Generate Markdown report
    print("Generating Markdown report...")
    markdown = generate_markdown_report(data)
    md_file = results_dir / "benchmark_summary.md"
    with open(md_file, 'w') as f:
        f.write(markdown)
    
    # Generate CSV summary
    print("Generating CSV summary...")
    csv_data = generate_csv_summary(data)
    csv_file = results_dir / "benchmark_summary.csv"
    with open(csv_file, 'w', newline='') as f:
        if csv_data:
            writer = csv.DictWriter(f, fieldnames=csv_data[0].keys())
            writer.writeheader()
            writer.writerows(csv_data)
    
    # Save complete JSON
    print("Generating JSON summary...")
    json_file = results_dir / "benchmark_summary.json"
    with open(json_file, 'w') as f:
        json.dump(data, f, indent=2)
    
    print("\n" + "="*70)
    print("Report Generation Complete!")
    print("="*70)
    print(f"\nGenerated files:")
    print(f"  - {md_file}")
    print(f"  - {csv_file}")
    print(f"  - {json_file}")
    print()

if __name__ == "__main__":
    main()
